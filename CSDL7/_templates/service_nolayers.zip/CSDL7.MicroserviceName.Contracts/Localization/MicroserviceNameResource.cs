﻿using Volo.Abp.Localization;

namespace CSDL7.MicroserviceName.Localization;

[LocalizationResourceName("MicroserviceName")]
public class MicroserviceNameResource
{

}
