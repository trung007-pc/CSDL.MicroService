﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;

namespace CSDL7.MicroserviceName.Controllers;

[Route("api/service-name-without-suffix/demo")]
[Area(ServiceNameWithoutSuffixRemoteServiceConsts.ModuleName)]
[RemoteService(Name = ServiceNameWithoutSuffixRemoteServiceConsts.RemoteServiceName)]
public class DemoController : AbpController
{
    [HttpGet]
    [Route("hello")]
    public async Task<string> HelloWorld()
    {
        return await Task.FromResult("Hello World!");
    }
    
    [HttpGet]
    [Route("hello-authorized")]
    [Authorize]
    public async Task<string> HelloWorldAuthorized()
    {
        return await Task.FromResult("Hello World (Authorized)!");
    }
}