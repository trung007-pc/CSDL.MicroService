﻿using CSDL7.MicroserviceName.Localization;
using Volo.Abp.Application.Services;

namespace CSDL7.MicroserviceName;

public abstract class ServiceNameWithoutSuffixAppService : ApplicationService
{
    protected ServiceNameWithoutSuffixAppService()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(CSDL7MicroserviceNameModule);
    }
}