﻿using Xunit;

namespace CSDL7.MicroserviceName.Tests.MongoDB;

public class MicroserviceNameMongoDbCollectionFixtureBase : ICollectionFixture<MicroserviceNameMongoDbFixture>
{

}