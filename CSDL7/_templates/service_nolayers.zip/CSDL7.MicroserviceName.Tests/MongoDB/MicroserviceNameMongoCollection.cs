﻿using Xunit;

namespace CSDL7.MicroserviceName.Tests.MongoDB;

[CollectionDefinition("MicroserviceName collection")]
public class MicroserviceNameMongoCollection: MicroserviceNameMongoDbCollectionFixtureBase
{

}