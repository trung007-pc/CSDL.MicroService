﻿namespace CSDL7.MicroserviceName.Navigation;

public class MicroserviceNameMenus
{
    private const string Prefix = "MicroserviceName";

    public const string Home = Prefix + ".Home";
    
}
