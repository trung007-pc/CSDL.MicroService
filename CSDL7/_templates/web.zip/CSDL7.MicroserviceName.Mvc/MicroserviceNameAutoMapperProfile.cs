using Volo.Abp.AutoMapper;
using AutoMapper;

namespace CSDL7.MicroserviceName;

public class MicroserviceNameWebAutoMapperProfile : Profile
{
    public MicroserviceNameWebAutoMapperProfile()
    {
        /* Create your AutoMapper object mappings here */
    }
}