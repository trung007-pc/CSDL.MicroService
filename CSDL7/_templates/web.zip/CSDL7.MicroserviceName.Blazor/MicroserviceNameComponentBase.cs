﻿using Volo.Abp.AspNetCore.Components;

namespace CSDL7.MicroserviceName;

public abstract class MicroserviceNameComponentBase : AbpComponentBase
{
    protected MicroserviceNameComponentBase()
    {

    }
}
