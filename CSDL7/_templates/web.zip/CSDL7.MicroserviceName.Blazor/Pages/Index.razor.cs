﻿namespace CSDL7.MicroserviceName.Pages;

public partial class Index
{

}
