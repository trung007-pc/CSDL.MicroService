using AutoMapper;

namespace CSDL7.MicroserviceName;

public class MicroserviceNameAutoMapperProfile : Profile
{
    public MicroserviceNameAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Blazor project.
    }
}
