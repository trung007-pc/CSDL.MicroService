﻿using Volo.Abp.Ui.Branding;

namespace CSDL7.MicroserviceName;

public class MicroserviceNameBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "MicroserviceName";
}
