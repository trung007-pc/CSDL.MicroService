﻿namespace CSDL7.MicroserviceName.Navigation;

public class MicroserviceNameNameMenus
{
    private const string Prefix = "MicroserviceName";

    public const string Home = Prefix + ".Home";
}
